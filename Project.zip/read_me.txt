Run the TCAS_system.m 

The output in the workspace will contain a 2-d Matrix with the 3 columns
representing RAs, WCs and TAs in that respective order.

Open the program_main.m and change the S to whatever row of signals should be 
tested and run through the Simulink model. Then run the script. The output
signals in the display will represent the RA, TA and WC for that signal set.