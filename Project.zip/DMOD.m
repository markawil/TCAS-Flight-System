% Mark Wilkinson
% EE 6083
% Gives DMOD, horizontal distance threshold

function d = DMOD(Oe, Te)
    d = Oe - Te;
end