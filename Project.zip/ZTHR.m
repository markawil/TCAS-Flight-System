% Mark Wilkinson
% EE 6083
% Gives ZTHR, vertical distance threshold

function z = ZTHR(On, Tn)
    z = On - Tn;
end