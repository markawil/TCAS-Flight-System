clear, clc

own_lat = 45;
own_long = 51;
own_height = 15000;
traf_lat = 45;
traf_long = 51;
traf_height = 17000;

sim("test_ENU");